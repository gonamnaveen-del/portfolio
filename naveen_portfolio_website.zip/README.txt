Naveen Gonam Portfolio Website

Files:
- index.html: complete responsive portfolio website (HTML, CSS, and JavaScript in one file).

How to preview:
1. Extract the ZIP file.
2. Open index.html in any modern browser.

Before publishing:
- Confirm the education institution names and dates.
- Confirm the certification titles.
- Replace/add exact project repository links once verified.
- Check that the LinkedIn and GitHub profile URLs are correct.
